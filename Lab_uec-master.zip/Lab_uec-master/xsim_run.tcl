run
exit
